# 开机之后执行
#!/system/bin/sh
# 请不要硬编码 /magisk/modname/... ; 请使用 $MODDIR/...
# 这将使你的脚本更加兼容 即使Magisk在未来改变了它的挂载点
MODDIR=${0%/*}
#解容4500毫安，如果你的电池数值不是4500可以更改为你所需要的，格式为4500后面加3个0
echo 4500000 > /sys/class/power_supply/bms/charge_full
echo 1 > /sys/class/power_supply/bms/cycle_count
echo 1 1 1 1 1 1 1 1 > /sys/class/power_supply/bms/cycle_counts
# 这个脚本将以 late_start service 模式执行
# 更多信息请访问 Magisk 主题