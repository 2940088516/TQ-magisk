SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

id="`grep_prop id $TMPDIR/module.prop`"
var_device="`grep_prop ro.product.*device`"
var_version="`grep_prop ro.build.version.release`"
B="`grep_prop author $TMPDIR/module.prop`"
C="`grep_prop name $TMPDIR/module.prop`"
D="`grep_prop description $TMPDIR/module.prop`"
ui_print "- *******************************"
ui_print "- 您的设备: $var_device"
ui_print "- 系统版本: $var_version"
ui_print "- $C    "
ui_print "- 作者：$B"
ui_print "- $D    "
ui_print "- *******************************"

# Set to true if you need to enable Magic Mount
# Most mods would like it to be enabled
SKIPMOUNT=false
#是否安装模块后自动关闭，改为true，安装后不会自动勾选启用

# Set to true if you need to load system.prop
PROPFILE=true
#是否使用common/system.prop文件

# Set to true if you need post-fs-data script
POSTFSDATA=false
#是否使用post-fs-data脚本执行文件

# Set to true if you need late_start service script
LATESTARTSERVICE=false
#是否在开机时候允许允许common/service.sh中脚本

##########################################################################################
# Installation Message
##########################################################################################

# Set what you want to show when installing your mod

print_modname() {
  ui_print "*******************************"
  ui_print " 已知刷入之后声音会变大的bug，低音效果不明显  "
  ui_print "*******************************"
}

##########################################################################################
# Replace list
##################################################################
set_perm_recursive  $MODPATH  0  0  0755  0644