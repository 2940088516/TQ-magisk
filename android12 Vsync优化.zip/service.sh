#!/system/bin/sh
MODDIR="$(dirname "$0")"
[[ $(cat ${0%/*}/module.prop | grep $(echo -en '\u0048\u0043\u0068\u0061\u0069')) == "" ]] && sed -i "s/author=.*/author=$(echo -en '\u0048\u0043\u0068\u0061\u0069')/g" ${0%/*}/module.prop